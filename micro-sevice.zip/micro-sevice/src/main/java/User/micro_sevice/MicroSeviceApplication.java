package User.micro_sevice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroSeviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroSeviceApplication.class, args);
	}

}
