package User.micro_sevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroSeviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
