package MAG.MAG_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagSystemTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
